<?php

require 'koneksi.php';
session_start();
if(isset($_SESSION['username'])){
  // $query = "SELECT * FROM user WHERE username='$_SESSION[`username`]'";
  // $result = mysqli_query($conn, $query);
}

$produk = mysqli_query($conn, "SELECT * FROM produk");

?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Toko Printer</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css" integrity="sha512-MV7K8+y+gLIBoVD59lQIYicR65iaqukzvf/nwasF0nqhPay5w/9lJmVM2hMDcnK1OnMGCdVK+iQrJ7lzPJQd1w==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        .kategori{
          text-decoration: none;
          color: black;
          font-size: 24px;
        }
    </style>
  </head>
  <body>

    <div class="collapse" id="navbarToggleExternalContent">
        <div class="bg-dark p-4">
          <h5 class="text-white h4">Toko Printer</h5>
          <span class="text-muted">Menjual berbagai printer</span>
        </div>
      </div>
      <nav class="navbar navbar-light bg-light ms-5">
        <div class="container">
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarToggleExternalContent" aria-controls="navbarToggleExternalContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <form class="d-flex" role="search">
            <input class="form-control me-2" type="search" placeholder="lagi cari apa?" aria-label="Search">
            <button class="btn btn-outline-success" type="submit">Search</button>
          </form>

          <?php if(isset($_SESSION["username"])) : ?>
              <a href="" class="btn" style="margin-left: 500px;">Halo, <?= $_SESSION["username"]; ?></a>
              <a href="logout.php" class="btn btn-primary px-4 py-2">Logout</a>
          <?php endif; ?>
            
          <?php if(!isset($_SESSION["username"])) : ?>
            <a href="auth/login/index.php" class="btn btn-primary" style="margin-left: 500px;">Login</a>
            <a href="auth/register/index.php" class="btn btn-outline-primary">Register</a>
          <?php endif; ?>
        </div>
      </nav>
      <section class="container">
        <div class="row mt-5">
          <div class="col">
            <h4 class="fs-1 fw-bold">Kategori Pilihan</h4>
          </div>
        </div>
        <hr>

        <div class="row mt-3">
          <div class="col">
            <a href="" class="kategori">
            <div class="card card-categories py-3">
             <div class="image-card text-center">
               <img src="assets/images/laserjet.jpg" alt="printer3" class="img-fluid">
            </div>
            <div class="text-card text-center mt-2">Printer Laserjet</div>
            </div>
            </a>
          </div>

          <div class="col">
            <a href="" class="kategori">
            <div class="card card-categories py-3">
             <div class="image-card text-center">
               <img src="assets/images/epson.jpeg" alt="printer2" class="img-fluid">
            </div>
            <div class="text-card text-center mt-2">Printer Epson</div>
            </div>
            </a>
          </div>
          
          <div class="col">
            <a href="" class="kategori">
            <div class="card card-categories py-3">
             <div class="image-card text-center">
               <img src="assets/images/laserjet.jpg" alt="printer3" class="img-fluid">
            </div>
            <div class="text-card text-center mt-2">Printer Laserjet</div>
            </div>
            </a>
          </div>
          
          <div class="col">
            <a href="" class="kategori">
            <div class="card card-categories py-3">
             <div class="image-card text-center">
               <img src="assets/images/epson.jpeg" alt="printer2" class="img-fluid">
            </div>
            <div class="text-card text-center mt-2">Printer Epson</div>
            </div>
            </a>
          </div>
          
          <div class="col">
            <a href="" class="kategori">
            <div class="card card-categories py-3">
             <div class="image-card text-center">
               <img src="assets/images/laserjet.jpg" alt="printer3" class="img-fluid">
            </div>
            <div class="text-card text-center mt-2">Printer Laserjet</div>
            </div>
            </a>
          </div>
  </section>

   <div class="container mt-4">

    <div class="row">
      <div class="col">
        <h4 class="fs-1 fw-bold"> Produk </h4>
        <hr class=""> 
      </div>
    </div>

    <div class="row">
      <?php $i = 1; ?>
      <?php foreach($produk as $data) : ?>
      <div class="col d-flex justify-content-between">
        <div class="card" style="width: 18rem;">
          <img src="assets/images/<?= $data["foto"]; ?>" class="card-img-top" height="300px" alt="">
          <div class="card-body">
            <h5 class="card-title"><?= $data["nama_produk"]; ?></h5>
            <h5 class="card-title"><?= $data["harga"]; ?></h5>
            <a href="detail-produk/index.php?id=<?= $data["id_produk"]; ?>" class="btn btn-primary">Beli Sekarang</a>
          </div>
        </div>  

      </div>
      <?php $i++ ?>
        <?php endforeach; ?>
    </div>

    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>
  </body>
</html>